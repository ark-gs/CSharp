﻿using System;

namespace SwitchFallThrough
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter day number (1-7): ");
            int dayNumber = Convert.ToInt32(Console.ReadLine());

            switch (dayNumber)
            {
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                    Console.WriteLine("It is Weekday.");
                    break;

                case 1:
                case 7:
                    Console.WriteLine("It is Weekend!");
                    break;

                default:
                    Console.WriteLine("*** Invalid day number entered ***");
                    break;
            }

            Console.ReadKey();
        }
    }
}
