﻿using System;

namespace WhileLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            //int counter = 1;
            //int sumEven = 0, sumOdd = 0;

            //while (counter <= 100)
            //{
            //    if (counter % 2 == 0)
            //        sumEven += counter;
            //    else
            //        sumOdd += counter;

            //    counter++;
            //}

            //Console.WriteLine("Sum Even => " + sumEven);
            //Console.WriteLine("Sum Odd  => " + sumOdd);

            ////Variations
            ////control variable may be of any data type
            //double counter = 1.0;
            //double sum = 0;

            //while (counter < 10.5)
            //{
            //    sum += counter;
            //    counter += 0.5;
            //}

            //Console.WriteLine("Sum => " + sum);

            ////The test-condition can be any boolean expression
            //int counter = 1;
            //bool exitLoop = false;

            //while (!exitLoop)
            //{
            //    Console.WriteLine("Loop Counter " + counter);

            //    if (counter % 7 == 0)
            //        exitLoop = true;

            //    counter++;
            //}

            //infinite while loop - green line
            while (true)
            {
                Console.WriteLine("I'm in infinite loop");
            }

            Console.ReadKey();
        }
    }
}
