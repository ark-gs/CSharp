﻿using System;

namespace DecrementOperator
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 7;
            x--;
            Console.WriteLine(x);  //Should output 6

            int y = 7;
            --y;
            Console.WriteLine(y);  //Should output 6

            //Use as an expression
            int a = 7;
            int ressult1;
            ressult1 = a--;
            Console.WriteLine(ressult1);  //Should output 7


            int b = 7;
            int result2;
            result2 = --b;
            Console.WriteLine(result2);  //Should output 6

            Console.ReadKey();
        }
    }
}
