﻿using System;

namespace ForLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            //for (int counter = 0; counter < 5; counter++)
            //    Console.WriteLine("Loop Counter " + counter);

            ////Reverse loop
            //for (int counter = 5; counter > 0; counter--)
            //    Console.WriteLine("Loop Counter " + counter);

            ////variations
            ////loop control variable can be of any data type
            //for (double counter = 1.0; counter < 7.5; counter += 0.5)
            //    Console.WriteLine("Loop Counter " + counter);

            ////Multiple initialisation and update statements
            //for (int i = 0, j = 5; i < 10; i++, j += 2)
            //    Console.WriteLine("i = " + i + "  j = " + j);

            ////Test condition need not be limiting to the control variable
            //bool exitLoop = false;
            //for (int counter = 1; !exitLoop; counter++)
            //{
            //    Console.WriteLine("Loop Counter " + counter);

            //    if (counter % 7 == 0)
            //        exitLoop = true;
            //}

            ////optional initialisation/update
            //int counter = 0;
            //for (; counter < 5;)
            //{
            //    Console.WriteLine("Loop Counter " + counter);
            //    counter++;
            //}

            ////Empty loop
            //for (int counter = 0; counter < 5; counter++) ;

            //infinite loop
            for (; ; )
                Console.WriteLine("infinite loop");

            Console.ReadKey();
        }
    }
}
