﻿using System;

namespace ArithmeticOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Addition Operator");
            Console.WriteLine(15 + 4);
            Console.WriteLine(5 + 4.3);

            Console.WriteLine("Subtraction Operator");
            Console.WriteLine(45 - 13);
            Console.WriteLine(5 - 3.3);

            Console.WriteLine("Multiplication Operator");
            Console.WriteLine(5 * 4);
            Console.WriteLine(0.5 * 5.5);

            Console.WriteLine("Division Operator");
            Console.WriteLine(14 / 5);
            Console.WriteLine(-14 / 5);
            Console.WriteLine(14.0 / 5);
            Console.WriteLine(-14 / 5.0);

            Console.WriteLine("Modulus Operator");
            Console.WriteLine(5 % 4);
            Console.WriteLine(-5 % 4);

            Console.ReadKey();
        }
    }
}
