﻿using System;

namespace LogicalOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Logical Negation Operator !");
            Console.WriteLine("!true  => " + !true);
            Console.WriteLine("!false => " + !false);

            Console.WriteLine("Logical AND Operator &&");
            Console.WriteLine("(15 > 3)  && (15 < 25) => " + ((15 > 3) && (15 < 25)));
            Console.WriteLine("(15 > 23) && (15 < 25) => " + ((15 > 23) && (15 < 25)));

            bool result1 = (15 > 3) || (15 < 25);
            bool result2 = (15 > 23) || (15 < 25);

            Console.WriteLine("Logical OR Operator ||");
            Console.WriteLine("(15 > 3)  || (15 < 25)  => " + result1);
            Console.WriteLine("(15 > 23) || (15 < 25)  => " + result2);

            Console.WriteLine("\n!result2  => " + !result2);

            Console.ReadKey();
        }
    }
}
