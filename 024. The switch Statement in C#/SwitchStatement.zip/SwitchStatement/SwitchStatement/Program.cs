﻿using System;

namespace SwitchStatement
{
    class Program
    {
        static void Main(string[] args)
        {
            double salesTax = 5;
            double netPrice;

            Console.Write("Enter Sales Price: ");
            double salePrice = Convert.ToDouble(Console.ReadLine());

            switch (salePrice)
            {
                case > 100:
                    salePrice = salePrice - (salePrice * 10 / 100);
                    Console.WriteLine("Discount applied: 10%");
                    break;

                case > 50:
                    salePrice = salePrice - (salePrice * 5 / 100);
                    Console.WriteLine("Discount applied: 5%");
                    break;

                default:
                    salePrice = salePrice - (salePrice * 2 / 100);
                    Console.WriteLine("Discount applied: 2%");
                    break;
            }

            netPrice = salePrice + (salePrice * salesTax / 100);

            Console.WriteLine("Net Price: " + netPrice);

            Console.ReadKey();

        }
    }
}
