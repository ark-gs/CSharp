﻿using System;

namespace AssignmentOperator1
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 10;

            //x = x + 2;
            x += 2;

            Console.WriteLine(x);

            Console.ReadKey();
        }
    }
}
