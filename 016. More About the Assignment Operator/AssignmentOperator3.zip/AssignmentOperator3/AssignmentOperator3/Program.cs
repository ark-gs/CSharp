﻿using System;

namespace AssignmentOperator3
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 5;
            int y = 7;

            Console.WriteLine("x == y => " + (x == y));
            Console.WriteLine("x = y  => " + (x = y));

            Console.WriteLine("x => " + x);
            Console.WriteLine("y => " + y);

            Console.ReadKey();
        }
    }
}
