﻿using System;

namespace AssignmentOperator2
{
    class Program
    {
        static void Main(string[] args)
        {
            int x, y, z, p, q;
            x = y = z = p = q = 10;

            x += 2;
            y -= 2;
            z *= 2;
            p /= 2;
            q %= 2;

            Console.WriteLine("x = " + x);
            Console.WriteLine("y = " + y);
            Console.WriteLine("z = " + z);
            Console.WriteLine("p = " + p);
            Console.WriteLine("q = " + q);

            Console.ReadKey();
        }
    }
}
