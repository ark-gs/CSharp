﻿using System;

namespace TypeConversions
{
    class Program
    {
        static void Main(string[] args)
        {
            double doubleNum = 1122.7;
            int intNum;
            intNum = (int) doubleNum;

            Console.WriteLine("doubleNum = " + doubleNum);
            Console.WriteLine("intNum = " + intNum);

            int sum = 60;
            int count = 80;

            double average = (double) sum / count;
            Console.WriteLine("average = " + average);

            Console.ReadKey();
        }
    }
}
