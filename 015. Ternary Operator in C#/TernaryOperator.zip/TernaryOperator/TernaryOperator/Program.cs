﻿using System;

namespace TernaryOperator
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 17, y = 10;

            string result = x > y ? "x is greater than y" : "x is less than y";
            Console.WriteLine(result);

            int salePrice = 85;
            Console.WriteLine(salePrice > 100 ? 10 : 8);

            Console.ReadKey();
        }
    }
}
