﻿using System;

namespace DoWhileLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            char character = 'A';

            do
            {
                Console.Write(character + " ");
                character++;
            }
            while (character <= 'Z');


            Console.ReadKey();
        }
    }
}
