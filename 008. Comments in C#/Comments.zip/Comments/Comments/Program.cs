﻿using System;

namespace Comments
{
    class Program
    {
        static void Main(string[] args)
        {
            //Initialise the counter
            int counter = 1;
            //TODO: Implement the ComputeXValue method

            Console.Write("Hello C# world");  //Comments can be placed after a statement

            /* This is a comment
            This is also a comment
            This is yet another comment
            */

            Console.Write("counter: " + counter);  /* Comments can be placed after a statement */
            // TODO: Implement the ComputeYValue method

            /* This is a comment line
             * This is another line
             * Third line
             */

        }
    }
}
