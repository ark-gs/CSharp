﻿using System;

namespace HelloCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello CSharp");
            Console.ReadLine();
        }
    }
}
