﻿using System;

namespace StringDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string myString1 = "Save Water";
            string myString2 = "John\'s Laptop";
            string myString3 = "Hello \"World!\"";
            string myString4 = "Hello\n World!";
            string myString5 = "Hello\t World";

            string myString6 = "Yen sign: " + '\u00a5';

            Console.WriteLine(myString1);
            Console.WriteLine(myString2);
            Console.WriteLine(myString3);
            Console.WriteLine(myString4);
            Console.WriteLine(myString5);
            Console.WriteLine(myString6);

            Console.ReadKey();
        }
    }
}
