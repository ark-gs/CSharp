﻿using System;

namespace EvenOdd
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 10;
            string returnValue = CheckEvenOdd(n);
            Console.WriteLine(returnValue);

            returnValue = CheckEvenOdd((int) 8.5);
            Console.WriteLine(returnValue);

            Console.WriteLine(CheckEvenOdd((int)25.5));

            Console.ReadKey();
        }

        static string CheckEvenOdd(int num)
        {
            //string result = (num % 2 == 0) ? "Even" : "Odd";
            //return result;

            return (num % 2 == 0) ? "Even" : "Odd";
        }
    }
}
