﻿using System;

namespace HelloMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            DisplayMessage();

            Console.ReadKey();
        }

        static void DisplayMessage()
        {
            Console.WriteLine("Hello from the Method!");
        }
    }
}
