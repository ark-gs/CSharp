﻿using System;

namespace ComparisonOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Less Than Operator <");
            Console.WriteLine(8.0 < 4.2);
            Console.WriteLine(4.2 < 4.2);
            Console.WriteLine(0.0 < 4.2);

            Console.WriteLine("Greater Than Operator");
            Console.WriteLine(8.0 > 4.2);
            Console.WriteLine(4.2 > 4.2);
            Console.WriteLine(0.0 > 4.2);

            Console.WriteLine("Less Than or Equal Operator <=");
            Console.WriteLine(8.0 <= 4.2);
            Console.WriteLine(4.2 <= 4.2);
            Console.WriteLine(0.0 <= 4.2);

            Console.WriteLine("Greater Than or Equal Operator >=");
            Console.WriteLine(8.0 >= 4.2);
            Console.WriteLine(4.2 >= 4.2);
            Console.WriteLine(0.0 >= 4.2);

            Console.WriteLine("Equal Operator ==");
            int a = 4 + 3;
            int b = 7;
            Console.WriteLine(a == b);

            char c1 = 'a';
            char c2 = 'A';
            Console.WriteLine(c1 == c2);

            Console.WriteLine("Inequality Operator !=");
            int x = 1 + 1 + 2 + 3;
            int y = 6;
            Console.WriteLine(x != y);

            string s1 = "Hello";
            string s2 = "Hello";
            Console.WriteLine(s1 != s2);

            Console.ReadKey();
        }
    }
}
