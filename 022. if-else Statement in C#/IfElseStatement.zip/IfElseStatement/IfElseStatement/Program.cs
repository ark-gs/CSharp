﻿using System;

namespace IfElseStatement
{
    class Program
    {
        static void Main(string[] args)
        {
            double salesTax = 5;
            double netPrice;

            Console.Write("Enter Sales Price: ");
            double salePrice = Convert.ToDouble(Console.ReadLine());

            double salePriceSave = salePrice;

            if (salePrice > 100)
                salePrice = salePrice - (salePrice * 10 / 100);
            else
                salePrice = salePrice - (salePrice * 5 / 100);

            netPrice = salePrice + (salePrice * salesTax / 100);

            Console.WriteLine("Net Price1: " + netPrice);

            // Using ternary operator
            salePriceSave = salePriceSave > 100 ? salePriceSave - (salePriceSave * 10 / 100) : salePriceSave - (salePriceSave * 5 / 100);

            netPrice = salePriceSave + (salePriceSave * salesTax / 100);

            Console.WriteLine("Net Price2: " + netPrice);

            Console.ReadKey();
        }
    }
}
