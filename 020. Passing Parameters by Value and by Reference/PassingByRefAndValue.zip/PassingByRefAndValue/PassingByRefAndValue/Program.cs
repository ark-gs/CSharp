﻿using System;

namespace PassingByRefAndValue
{
    class Program
    {
        static void Main(string[] args)
        {
            int argument;

            // Passing by value.
            // The value of argument in Main is not changed.
            argument = 4;
            SquareByValue(argument);
            Console.WriteLine("SquareByValue: " + argument);

            // Passing by reference.
            // The value of argument in Main is changed.
            argument = 4;
            SquareByRef(ref argument);
            Console.WriteLine("SquareByRef: " + argument);

            Console.ReadKey();
        }

        static void SquareByValue(int valParameter)
        {
            valParameter *= valParameter;
            Console.WriteLine("Inside Method SquareByValue: " + valParameter);
        }

        static void SquareByRef(ref int refParameter)
        {
            refParameter *= refParameter;
            Console.WriteLine("Inside Method SquareByRef: " + refParameter);
        }
    }
}
