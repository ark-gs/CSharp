﻿using System;

namespace DataTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            int intNumber = 12345;
            byte byteNumber;
            byteNumber = 255;

            float floatNumber = 123.45F;
            double doubleNumber = 23.56;
            decimal decimalNumber = 12.1212123123123M;

            bool booleanFlag = true;

            char charVariable = 'G';

            Console.WriteLine("intNumber: " + intNumber);
            Console.WriteLine("byteNumber: " + byteNumber);
            Console.WriteLine("floatNumber: " + floatNumber);
            Console.WriteLine("doubleNumber: " + doubleNumber);
            Console.WriteLine("decimalNumber: " + decimalNumber);
            Console.WriteLine("booleanFlag: " + booleanFlag);
            Console.WriteLine("charVariable: " + charVariable);

            Console.ReadKey();
        }
    }
}
