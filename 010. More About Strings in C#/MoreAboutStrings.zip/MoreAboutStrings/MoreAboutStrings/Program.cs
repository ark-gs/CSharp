﻿using System;

namespace MoreAboutStrings
{
    class Program
    {
        static void Main(string[] args)
        {
            string strGreetings1 = "Hello";
            string strGreetings2 = "there!";

            Console.WriteLine(strGreetings1 + " " + strGreetings2);

            Console.Write("What is your name? ");
            string userName = Console.ReadLine();

            Console.Write("What is your age? ");
            int userAge = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Hi " + userName);
            Console.WriteLine();
            Console.WriteLine("You are " + userAge + " years old");

            Console.ReadKey();
        }
    }
}
